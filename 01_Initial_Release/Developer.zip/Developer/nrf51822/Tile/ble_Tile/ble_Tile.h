														/****************************************************************************


        
        
                         R E V E A L   L A B S  I N C.
        
        
                      Copyright 2013 Reveal Labs Inc.
                              All Rights Reserved
        
        
        
                           Confidential Information
                Limited Distribution to Authorized Persons Only
               Created 2013 and Protected as an Unpublished Work
                     Under the U.S. Copyright Act of 1976
        
        
        

				This   is   a   proprietary   work    to    which  
           		Reveal Labs Inc.  claims   exclusive       right.
				No  part  of this work may  be  used,  disclosed,
				reproduced,  stored  in an information  retrieval
				system,  or  transmitted,  in any form or by  any
				means,   electronic,   mechanical,  photocopying,
				recording,   or  otherwise,   without  the  prior
				written permission of Reveal Labs Inc.

	

****************************************************************************/

/**@file
 *
 * @defgroup ble_sdk_srv_tile Tile Device Control
 * @{
 * @ingroup  ble_sdk_srv
 * @brief    Tile Device Control Service
 *
 * @details  The Tile Device Control Service (TILE) is a GATT based service that can be used for
 *           controlling all aspects of the Tile device.
 */

#ifndef BLE_TILE_H__
#define BLE_TILE_H__

#include <stdint.h>
#include "ble_gatts.h"
#include "ble.h"
#include "ble_srv_common.h"

#define BLE_TILE_SERVICE_UUID          0x1000                            /**< The UUID of the TILE Service. */
#define BLE_TILE_SLP_CTRL_PT_UUID      0x1001                            /**< The UUID of the TILE Sleep Control Point. */
#define BLE_TILE_RSSI_UUID             0x0000                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_SPKR_UUID             0x0001                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_LED_UUID              0x0002                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_LED_ON_UUID           0x0003                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_LED_OFF_UUID          0x0004                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T1_FREQ_UUID          0x0005                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T1_ON_PER_UUID        0x0006                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T1_OFF_PER_UUID       0x0007                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T2_FREQ_UUID          0x0008                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T2_ON_PER_UUID        0x0009                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_T2_OFF_PER_UUID       0x000A                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_BETWEEN_TONES_UUID    0x000B                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_AUTH_UUID             0x000C                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_DATE_MFG_UUID         0x000D                            /**< The UUID of the TILE Packet Characteristic. */
#define BLE_TILE_NUM_ALERTS_UUID       0x000E                            /**< The UUID of the TILE Packet Characteristic. */


/**@brief   TILE Event type.
 *
 * @details This enumeration contains the types of events that will be received from the TILE Service.
 */
typedef enum {
    BLE_TILE_START,                                                      /**< The event indicating that the peer wants the application to prepare for a new firmware update. */
    BLE_TILE_RECEIVE_INIT_DATA,                                          /**< The event indicating that the peer wants the application to prepare to receive init parameters. */
    BLE_TILE_RECEIVE_APP_DATA,                                           /**< The event indicating that the peer wants the application to prepare to receive the new firmware image. */
    BLE_TILE_VALIDATE,                                                   /**< The event indicating that the peer wants the application to validate the newly received firmware image. */
    BLE_TILE_ACTIVATE_N_RESET,                                           /**< The event indicating that the peer wants the application to undergo activate new firmware and restart with new valid application */
    BLE_TILE_SYS_RESET,                                                  /**< The event indicating that the peer wants the application to undergo a reset and start the currently valid application image.*/
    BLE_TILE_PKT_RCPT_NOTIF_ENABLED,                                     /**< The event indicating that the peer has enabled packet receipt notifications. It is the responsibility of the application to call @ref ble_tile_pkts_rcpt_notify each time the number of packets indicated by num_of_pkts field in @ref ble_tile_evt_t is received.*/
    BLE_TILE_PKT_RCPT_NOTIF_DISABLED,                                    /**< The event indicating that the peer has disabled the packet receipt notifications.*/
    BLE_TILE_PACKET_WRITE,                                               /**< The event indicating that the peer has written a value to the 'TILE Packet' characteristic. The data received from the peer will be present in the @ref ble_tile_pkt_write element contained within @ref ble_tile_evt_t.*/
    BLE_TILE_BYTES_RECEIVED_SEND                                         /**< The event indicating that the peer is requesting for the number of bytes of firmware data last received by the application. It is the responsibility of the application to call @ref ble_tile_pkts_rcpt_notify in response to this event. */
} ble_tile_evt_type_t;

/**@brief   TILE Procedure type.
 *
 * @details This enumeration contains the types of TILE procedures.
 */
typedef enum {
    BLE_TILE_START_PROCEDURE        = 1,                                 /**< TILE Start procedure.*/
    BLE_TILE_INIT_PROCEDURE         = 2,                                 /**< TILE Initialization procedure.*/
    BLE_TILE_RECEIVE_APP_PROCEDURE  = 3,                                 /**< Firmware receiving procedure.*/
    BLE_TILE_VALIDATE_PROCEDURE     = 4,                                 /**< Firmware image validation procedure .*/
    BLE_TILE_PKT_RCPT_REQ_PROCEDURE = 8                                  /**< Packet receipt notification request procedure. */
} ble_tile_procedure_t;

/**@brief   TILE Response value type.
 */
typedef enum {
    BLE_TILE_RESP_VAL_SUCCESS = 1,                                       /**< Success.*/
    BLE_TILE_RESP_VAL_INVALID_STATE,                                     /**< Invalid state.*/
    BLE_TILE_RESP_VAL_NOT_SUPPORTED,                                     /**< Operation not supported.*/
    BLE_TILE_RESP_VAL_DATA_SIZE,                                         /**< Data size exceeds limit.*/
    BLE_TILE_RESP_VAL_CRC_ERROR,                                         /**< CRC Error.*/
    BLE_TILE_RESP_VAL_OPER_FAILED                                        /**< Operation failed.*/
} ble_tile_resp_val_t;

/**@brief   TILE Packet structure.
 *
 * @details This structure contains the value of the TILE Packet characteristic as written by the
 *          peer and the length of the value written. It will be filled by the TILE Service when the
 *          peer writes to the TILE Packet characteristic.
 */
typedef struct {
    uint8_t                      len;                                   /**< Length of the packet received. */
    uint8_t *                    p_data;                                /**< Pointer to the received packet. This will point to a word aligned memory location.*/
} ble_tile_pkt_write_t;

/**@brief   Packet receipt notification request structure.
 *
 * @details This structure contains the contents of the packet receipt notification request
 *          sent by the TILE Controller.
 */
typedef struct {
    uint16_t                     num_of_pkts;                           /**< The number of packets of firmware data to be received by application before sending the next Packet Receipt Notification to the peer. */
} ble_pkt_rcpt_notif_req_t;

/**@brief   TILE Event structure.
 *
 * @details This structure contains the event generated by the TILE Service based on the data
 *          received from the peer.
 */
typedef struct {
    ble_tile_evt_type_t           ble_tile_evt_type;                      /**< Type of the event.*/
    union
    {
        ble_tile_pkt_write_t      ble_tile_pkt_write;                     /**< The TILE packet received. This field is when the @ref ble_tile_evt_type field is set to @ref BLE_TILE_PACKET_WRITE.*/
        ble_pkt_rcpt_notif_req_t pkt_rcpt_notif_req;                    /**< Packet receipt notification request. This field is when the @ref ble_tile_evt_type field is set to @ref BLE_TILE_PKT_RCPT_NOTIF_ENABLED.*/
    } evt;
} ble_tile_evt_t;

// Forward declaration of the ble_tile_t type.
typedef struct ble_tile_s ble_tile_t;

/**@brief TILE Service event handler type. */
typedef void (*ble_tile_evt_handler_t) (ble_tile_t * p_tile, ble_tile_evt_t * p_evt);

/**@brief   TILE service structure.
 *
 * @details This structure contains status information related to the service.
 */
typedef struct ble_tile_s {
    uint16_t                     conn_handle;                           /**< Handle of the current connection (as provided by the BLE stack, is BLE_CONN_HANDLE_INVALID if not in a connection). */
    uint16_t                     service_handle;                        /**< Handle of TILE Service (as provided by the BLE stack). */
    uint8_t                      uuid_type;                             /**< UUID type assigned for TILE Service by the BLE stack. */
    ble_gatts_char_handles_t     tile_pkt_handles;                       /**< Handles related to the TILE Packet characteristic. */
    ble_gatts_char_handles_t     tile_ctrl_pt_handles;                   /**< Handles related to the TILE Control Point characteristic. */
    ble_gatts_char_handles_t     tile_status_rep_handles;                /**< Handles related to the TILE Status Report characteristic. */
    ble_tile_evt_handler_t        evt_handler;                           /**< The event handler to be called when an event is to be sent to the application.*/
    ble_srv_error_handler_t      error_handler;                         /**< Function to be called in case of an error. */
} ble_tile_t;

/**@brief      TILE service initialization structure.
 *
 * @details    This structure contains the initialization information for the TILE Service. The
 *             application needs to fill this structure and pass it to the TILE Service using the
 *             @ref ble_tile_init function.
 */
typedef struct {
    ble_tile_evt_handler_t        evt_handler;                           /**< Event handler to be called for handling events in the Device Firmware Update Service. */
    ble_srv_error_handler_t      error_handler;                         /**< Function to be called in case of an error. */
} ble_tile_init_t;

/**@brief      Function for handling a BLE stack event.
 *
 * @details    The TILE service expects the application to call this function each time an event
 *             is received from the BLE stack. This function processes the event, if it is relevant
 *             for the TILE service and calls the TILE event handler of the application if necessary.
 *
 * @param[in]  p_tile        Pointer to the TILE service structure.
 * @param[in]  p_ble_evt    Pointer to the event received from BLE stack.
 */
void ble_tile_on_ble_evt(ble_tile_t * p_tile, ble_evt_t * p_ble_evt);

/**@brief      Function for initializing the TILE service.
 *
 * @param[out] p_tile        Device Firmware Update service structure. This structure will have to be
 *                          supplied by the application. It will be initialized by this function,
 *                          and will later be used to identify the service instance.
 * @param[in]  p_tile_init   Information needed to initialize the service.
 *
 * @return     NRF_SUCCESS if the TILE service and its characteristics were successfully added to the
 *             BLE Stack. Otherwise an error code.
 *             This function returns NRF_ERROR_NULL if the value of evt_handler in p_tile_init
 *             structure provided is NULL or if the pointers supplied as input are NULL.
 */
uint32_t ble_tile_init(ble_tile_t * p_tile, ble_tile_init_t * p_tile_init);

/**@brief       Function for sending response to a control point command.
 *
 * @details     This function will encode a TILE Control Point response using the given input
 *              parameters and will send a notification of the same to the peer.
 *
 * @param[in]   p_tile       Pointer to the TILE service structure.
 * @param[in]   tile_proc    Procedure for which this response is to be sent.
 * @param[in]   resp_val    Response value.
 *
 * @return      NRF_SUCCESS if the TILE Service has successfully requested the BLE stack to send the
 *              notification. Otherwise an error code.
 *              This function returns NRF_ERROR_INVALID_STATE if the device is not connected to a
 *              peer or if the TILE service is not initialized or if the notification of the TILE
 *              Status Report characteristic was not enabled by the peer. It returns NRF_ERROR_NULL
 *              if the pointer p_tile is NULL.
 */
uint32_t ble_tile_response_send(ble_tile_t *          p_tile,
                               ble_tile_procedure_t  tile_proc,
                               ble_tile_resp_val_t   resp_val);

/**@brief      Function for notifying the peer about the number of bytes of firmware data received.
 *
 * @param[in]  p_tile                      Pointer to the TILE service structure.
 * @param[in]  num_of_firmware_bytes_rcvd Number of bytes.
 *
 * @return     NRF_SUCCESS if the TILE Service has successfully requested the BLE stack to send the
 *             notification. Otherwise an error code.
 *             This function returns NRF_ERROR_INVALID_STATE if the device is not connected to a
 *             peer or if the TILE service is not initialized or if the notification of the TILE
 *             Status Report characteristic was not enabled by the peer. It returns NRF_ERROR_NULL
 *             if the pointer p_tile is NULL.
 */
uint32_t ble_tile_bytes_rcvd_report(ble_tile_t * p_tile, uint32_t num_of_firmware_bytes_rcvd);

/**@brief      Function for sending Packet Receipt Notification to the peer.
 *
 *             This function will encode the number of bytes received as input parameter into a
 *             notification of the control point characteristic and send it to the peer.
 *
 * @param[in]  p_tile                      Pointer to the TILE service structure.
 * @param[in]  num_of_firmware_bytes_rcvd Number of bytes of firmware image received.
 *
 * @return     NRF_SUCCESS if the TILE Service has successfully requested the BLE stack to send the
 *             notification. Otherwise an error code.
 *             This function returns NRF_ERROR_INVALID_STATE if the device is not connected to a
 *             peer or if the TILE service is not initialized or if the notification of the TILE
 *             Status Report characteristic was not enabled by the peer. It returns NRF_ERROR_NULL
 *             if the pointer p_tile is NULL.
 */
uint32_t ble_tile_pkts_rcpt_notify(ble_tile_t * p_tile, uint32_t num_of_firmware_bytes_rcvd);

#endif // BLE_TILE_H__

/** @} */
