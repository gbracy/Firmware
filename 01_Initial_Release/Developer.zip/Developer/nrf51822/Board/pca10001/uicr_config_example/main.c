#include "nrf.h"
#include "uicr_config.h"
#include <stdint.h>
#include <stdbool.h>


int main(void)
{
    while (true)
    {
        /* Do nothing */
    }
}
